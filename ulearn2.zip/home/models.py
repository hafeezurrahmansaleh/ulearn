# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.contrib.auth.models import User
from django.db import models

class OrgType(models.Model):
    title = models.TextField(db_column='Title')
    value = models.TextField(db_column='Value')

    def __str__(self):
        return self.title



class OrgCategory(models.Model):
    title = models.TextField(db_column='Title')
    value = models.TextField(db_column='Value')

    def __str__(self):
        return self.title



class TechnicalArea(models.Model):
    title = models.TextField(db_column='Title')
    value = models.TextField(db_column='Value')

    def __str__(self):
        return self.title



class Dump(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    org_code = models.TextField(db_column='ORG_CODE', null=True)  # Field name made lowercase.
    organisation_name = models.TextField(db_column='Organisation_Name', null=True)  # Field name made lowercase.
    functionality = models.TextField(db_column='Functionality')  # Field name made lowercase.
    website = models.TextField(db_column='Website', null=True)  # Field name made lowercase.
    org_type = models.ForeignKey(OrgType, on_delete=models.CASCADE, null=True, related_name='org_type')  # Field name made lowercase.
    org_category = models.ForeignKey(OrgCategory, on_delete=models.CASCADE, null=True, related_name='org_category')  # Field name made lowercase.
    primary_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='primary_technicalsector')  # Field name made lowercase.
    secondary_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='secondary_technicalsector')  # Field name made lowercase.
    third_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='third_technicalsector')  # Field name made lowercase.
    fourth_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='fourth_technicalsector')  # Field name made lowercase.
    fifth_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='fifth_technicalsector')  # Field name made lowercase.
    eco_system_tag = models.TextField(db_column='Eco_System_tag', null=True)  # Field name made lowercase.
    eco_map_sector = models.TextField(db_column='Eco_Map_Sector', null=True)  # Field name made lowercase.
    eco_map_subsector = models.TextField(db_column='Eco_Map_SubSector', null=True)  # Field name made lowercase.
    number_of_convener = models.IntegerField(db_column='Number_of_Convener', null=True)  # Field name made lowercase.
    number_of_challenges = models.IntegerField(db_column='Number_of_Challenges', null=True)  # Field name made lowercase.
    number_of_innovations = models.IntegerField(db_column='Number_of_Innovations', null=True)  # Field name made lowercase.
    number_of_referrals = models.IntegerField(db_column='Number_of_referrals', null=True)  # Field name made lowercase.
    number_of_matchmaker = models.IntegerField(db_column='Number_of_Matchmaker', null=True)  # Field name made lowercase.
    number_of_matchmaker_solution_received = models.IntegerField(db_column='Number_of_Matchmaker_solution_Received', null=True)  # Field name made lowercase.
    number_of_projects_ril = models.IntegerField(db_column='Number_of_projects_RIL', null=True)  # Field name made lowercase.
    total_number_of_interactions_ril = models.IntegerField(db_column='Total_number_of_interactions_RIL', null=True)  # Field name made lowercase.
    ulearn_subcategory = models.TextField(db_column='Ulearn_Subcategory', null=True)  # Field name made lowercase.
    date_of_last_contact = models.DateField(db_column='Date_of_last_contact', null=True)  # Field name made lowercase.
    status_remarks = models.TextField(db_column='Status_Remarks', null=True)  # Field name made lowercase.
    primary_contact_name = models.TextField(db_column='Primary_Contact_Name', null=True)  # Field name made lowercase.
    role = models.TextField(db_column='Role')  # Field name made lowercase.
    email = models.TextField(db_column='Email')  # Field name made lowercase.
    phone = models.TextField(db_column='Phone')  # Field name made lowercase.
    optional_contact = models.TextField(db_column='Optional_Contact', null=True)  # Field name made lowercase.
    location_base = models.TextField(db_column='Location_Base', null=True)  # Field name made lowercase.
    district = models.TextField(db_column='District', null=True)  # Field name made lowercase.
    refugee_settlement = models.TextField(db_column='Refugee_Settlement', null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'dump'




class CleanData(models.Model):
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    org_code = models.TextField(db_column='ORG_CODE', null=True)  # Field name made lowercase.
    organisation_name = models.TextField(db_column='Organisation_Name', null=True)  # Field name made lowercase.
    functionality = models.TextField(db_column='Functionality', null=True)  # Field name made lowercase.
    website = models.TextField(db_column='Website', null=True)  # Field name made lowercase.
    org_type = models.ForeignKey(OrgType, on_delete=models.CASCADE, null=True, related_name='cd_org_type')  # Field name made lowercase.
    org_category = models.ForeignKey(OrgCategory, on_delete=models.CASCADE, null=True, related_name='cd_org_category')  # Field name made lowercase.
    primary_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='cd_primary_technicalsector')  # Field name made lowercase.
    secondary_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='cd_secondary_technicalsector')  # Field name made lowercase.
    third_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='cd_third_technicalsector')  # Field name made lowercase.
    fourth_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='cd_fourth_technicalsector')  # Field name made lowercase.
    fifth_technicalsector = models.ForeignKey(TechnicalArea, on_delete=models.CASCADE, null=True, related_name='cd_fifth_technicalsector')  # Field name made lowercase.
    eco_system_tag = models.TextField(db_column='Eco_System_tag', null=True)  # Field name made lowercase.
    eco_map_sector = models.TextField(db_column='Eco_Map_Sector', null=True)  # Field name made lowercase.
    eco_map_subsector = models.TextField(db_column='Eco_Map_SubSector', null=True)  # Field name made lowercase.
    number_of_convener = models.IntegerField(db_column='Number_of_Convener', null=True)  # Field name made lowercase.
    number_of_challenges = models.IntegerField(db_column='Number_of_Challenges', null=True)  # Field name made lowercase.
    number_of_innovations = models.IntegerField(db_column='Number_of_Innovations', null=True)  # Field name made lowercase.
    number_of_referrals = models.IntegerField(db_column='Number_of_referrals', null=True)  # Field name made lowercase.
    number_of_matchmaker = models.IntegerField(db_column='Number_of_Matchmaker', null=True)  # Field name made lowercase.
    number_of_matchmaker_solution_received = models.IntegerField(db_column='Number_of_Matchmaker_solution_Received', null=True)  # Field name made lowercase.
    number_of_projects_ril = models.IntegerField(db_column='Number_of_projects_RIL', null=True)  # Field name made lowercase.
    total_number_of_interactions_ril = models.IntegerField(db_column='Total_number_of_interactions_RIL', null=True)  # Field name made lowercase.
    ulearn_subcategory = models.TextField(db_column='Ulearn_Subcategory', null=True)  # Field name made lowercase.
    date_of_last_contact = models.DateField(db_column='Date_of_last_contact', null=True)  # Field name made lowercase.
    status_remarks = models.TextField(db_column='Status_Remarks', null=True)  # Field name made lowercase.
    primary_contact_name = models.TextField(db_column='Primary_Contact_Name', null=True)  # Field name made lowercase.
    role = models.TextField(db_column='Role', null=True)  # Field name made lowercase.
    email = models.TextField(db_column='Email', null=True)  # Field name made lowercase.
    phone = models.TextField(db_column='Phone', null=True)  # Field name made lowercase.
    optional_contact = models.TextField(db_column='Optional_Contact', null=True)  # Field name made lowercase.
    location_base = models.TextField(db_column='Location_Base', null=True)  # Field name made lowercase.
    district = models.TextField(db_column='District', null=True)  # Field name made lowercase.
    refugee_settlement = models.TextField(db_column='Refugee_Settlement', null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'dump'


