from django.shortcuts import render, redirect

# Create your views here.
from django.views import View
from .forms import ImportDataForm

class IndexView(View):
    def get(self, request):
        # companies = CompanyInfo.objects.all()
        context = {
            'companies': None
        }
        return render(request, 'advance_table.html', context)


class CleanDataView(View):
    def get(self, request):
        # companies = CompanyInfo.objects.all()
        context = {
            'companies': None
        }
        return render(request, 'clean_data.html', context)


class LoginView(View):
    def get(self, request):
        # companies = CompanyInfo.objects.all()
        context = {
            'companies': None
        }
        return render(request, 'login.html', context)


class ImportData(View):
    def get(self, request):
        # companies = CompanyInfo.objects.all()
        if request.method == 'POST':
            form = ImportDataForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('/')
        else:
            form = ImportDataForm()
            context = {
                'form': form
            }
            return render(request, 'input.html', context)


from django.shortcuts import render
import openpyxl


def import_excel(request):
    if "GET" == request.method:
        return render(request, '/', {})
    else:
        excel_file = request.FILES["excel_file"]

        # you may put validations here to check extension or file size

        wb = openpyxl.load_workbook(excel_file)

        # getting a particular sheet by name out of many sheets
        worksheet = wb["Sheet1"]
        print(worksheet)

        excel_data = list()
        # iterating over the rows and
        # getting value from each cell in row
        row_num = 0
        for row in worksheet.iter_rows():
            row_data = list()
            for cell in row:
                row_data.append(str(cell.value))
            excel_data.append(row_data)
            row_num = row_num + 1
        return render(request, 'exceldata.html', {"excel_data": excel_data})
