from django.contrib import admin
from . models import OrgType, OrgCategory, TechnicalArea, Dump, CleanData

# Register your models here.
admin.site.register(OrgType)
admin.site.register(OrgCategory)
admin.site.register(TechnicalArea)
admin.site.register(Dump)
admin.site.register(CleanData)
