from django.urls import path, include
from .views import *

urlpatterns = [
    path('filter-data/', DumpList.as_view()),
    path('org-types/', OrgTypeListView.as_view()),
    path('org-categories/', OrgCategoryListView.as_view()),
    path('technical-area/', TechnicalAreaListView.as_view()),
]