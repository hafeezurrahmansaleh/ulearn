import json

from django.apps import apps
from django.core import serializers as sz
from django.http import JsonResponse
# from knox.auth import TokenAuthentication
from rest_framework import generics
from rest_framework.exceptions import ValidationError
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.permissions import (
    IsAuthenticated
)
# from urllib3.connectionpool import xrange

from .serializers import *
# Create your views here.


class DumpList(generics.ListAPIView):
    """
       endpoint for retrieving all data
    """
    # permission_classes = (IsAuthenticated,)
    serializer_class = DumpDataSerializer
    # --queryset = Dump.objects.all()
    pagination_class = LimitOffsetPagination

    def get_queryset(self):
        dump_list = Dump.objects.all()
        return dump_list


class FilterDumpDataView(generics.ListAPIView):
    """
       endpoint for filtering clean data
    """
    # permission_classes = (IsAuthenticated,)
    serializer_class = DumpDataSerializer
    # --queryset = Dump.objects.all()
    pagination_class = LimitOffsetPagination

    def get_queryset(self):
        dump_list = Dump.objects.all()
        return dump_list


class OrgTypeListView(generics.ListAPIView):
    """
       endpoint for retrieving the list of organization types
    """
    # permission_classes = (IsAuthenticated,)
    serializer_class = OrgTypeSerializer
    # --queryset = Dump.objects.all()
    # pagination_class = LimitOffsetPagination

    def get_queryset(self):
        dump_list = OrgType.objects.all()
        return dump_list


class OrgCategoryListView(generics.ListAPIView):
    """
       endpoint for retrieving the list of organization categories
    """
    # permission_classes = (IsAuthenticated,)
    serializer_class = OrgCategorySerializer
    # --queryset = Dump.objects.all()
    # pagination_class = LimitOffsetPagination

    def get_queryset(self):
        dump_list = OrgCategory.objects.all()
        return dump_list


class TechnicalAreaListView(generics.ListAPIView):
    """
       endpoint for retrieving the list of technical areas
    """
    # permission_classes = (IsAuthenticated,)
    serializer_class = TechnicalAreaSerializer
    # --queryset = Dump.objects.all()
    # pagination_class = LimitOffsetPagination

    def get_queryset(self):
        dump_list = TechnicalArea.objects.all()
        return dump_list


